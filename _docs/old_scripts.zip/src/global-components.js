import Navbar from './components/global/navbar/navbar';
import Loader from './components/global/loader';

export default [
  Navbar,
  Loader
];