<template>
  <div
    id="spell-container"
    class="container-fluid p-4"
  >
    <h1 class="display-3 font-display mb-3">
      Écoles
    </h1>
  </div>
</template>

<script>

export default {
  name: 'SchoolsPage',
  metaInfo: {
    titleTemplate: '%s - Maîtrises'
  },
};

</script>

<style>

</style>