# auracle_client
The client version of the Auracle App
